import boto3
import pymysql
import sys
import logging
from botocore.exceptions import ClientError

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration (consider moving to environment variables or config file)
CONFIG = {
    'init_username': 'admin',
    'init_password': 'admin',
    'app_name': 'lostandfound-backend',
    'region': 'us-east-1',
    'admin_email': 'samuelongqixin@gmail.com'
}

# Resource trackers
RESOURCES = {
    'cognito_pool_id': None,
    'cognito_client_id': None,
    'cognito_identities_pool_id': None,
}

def handle_aws_error(func):
    """Decorator for AWS client error handling"""

    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ClientError as e:
            logger.error(f"AWS API error in {func.__name__}: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Unexpected error in {func.__name__}: {e}")
            sys.exit(1)

    return wrapper

@handle_aws_error
def create_cognito():
    """Create Cognito resources with proper configuration"""
    idp = boto3.client('cognito-idp', region_name=CONFIG['region'])
    identity = boto3.client('cognito-identity', region_name=CONFIG['region'])

    # Create user pool with username configuration
    pool_response = idp.create_user_pool(
        PoolName=f"{CONFIG['app_name']}-auth",
        Policies={
            'PasswordPolicy': {
                'MinimumLength': 8,
                'RequireUppercase': True,
                'RequireLowercase': True,
                'RequireNumbers': True,
                'RequireSymbols': True
            }
        },
        # Remove UsernameAttributes and use AliasAttributes instead
        AliasAttributes=["email"],  # Empty list means username-only authentication
        Schema=[{
            'Name': 'name',
            'AttributeDataType': 'String',
            'Required': True,
            'Mutable': True
        }],
        UsernameConfiguration={
            'CaseSensitive': False  # Optional: Makes usernames case-insensitive
        }
    )
    RESOURCES['cognito_pool_id'] = pool_response['UserPool']['Id']

    # Configure MFA for only authenticator apps (TOTP)
    idp.set_user_pool_mfa_config(
        MfaConfiguration='OPTIONAL',
        UserPoolId=RESOURCES['cognito_pool_id'],
        SoftwareTokenMfaConfiguration={
            'Enabled': True
        },
    )

    logger.info(f"Created Cognito User Pool: {RESOURCES['cognito_pool_id']}")

    # Create user pool client
    client_response = idp.create_user_pool_client(
        UserPoolId=RESOURCES['cognito_pool_id'],
        ClientName=f"{CONFIG['app_name']}-client",
        GenerateSecret=True,
        RefreshTokenValidity=30,
        ExplicitAuthFlows=[
            'ALLOW_ADMIN_USER_PASSWORD_AUTH',
            'ALLOW_USER_SRP_AUTH',
            'ALLOW_REFRESH_TOKEN_AUTH'
        ]
    )
    RESOURCES['cognito_client_id'] = client_response['UserPoolClient']['ClientId']
    logger.info(f"Created Cognito Client: {RESOURCES['cognito_client_id']}")

    # Create identity pool
    identity_response = identity.create_identity_pool(
        IdentityPoolName=f"{CONFIG['app_name']}-identity-pool",
        AllowUnauthenticatedIdentities=False,
        CognitoIdentityProviders=[{
            'ClientId': RESOURCES['cognito_client_id'],
            'ProviderName': f"cognito-idp.{CONFIG['region']}.amazonaws.com/{RESOURCES['cognito_pool_id']}"
        }]
    )
    RESOURCES['cognito_identities_pool_id'] = identity_response['IdentityPoolId']
    logger.info(f"Created Identity Pool: {RESOURCES['cognito_identities_pool_id']}")

    # Create admin user
    try:
        idp.admin_create_user(
            UserPoolId=RESOURCES['cognito_pool_id'],
            Username=CONFIG['init_username'],
            UserAttributes=[
                {'Name': 'email', 'Value': CONFIG['admin_email']},
                {'Name': 'email_verified', 'Value': 'true'},
                {'Name': 'name', 'Value': 'Admin'}
            ],
            TemporaryPassword=CONFIG['init_password'],
            MessageAction='SUPPRESS'
        )
        logger.info("Created admin user")
    except idp.exceptions.UsernameExistsException:
        logger.warning("Admin user already exists")

def main():
    """Main deployment workflow"""
    logger.info("Starting deployment...")
    create_cognito()

    logger.info("\nDeployment completed successfully!")
    print(f"Cognito Pool ID: {RESOURCES['cognito_pool_id']}")
    print(f"Cognito Client ID: {RESOURCES['cognito_client_id']}")
    print(f"Identity Pool ID: {RESOURCES['cognito_identities_pool_id']}")


if __name__ == "__main__":
    main()