import uuid
from chalice import Blueprint, BadRequestError, Response
import json
import boto3
import os
import traceback
import urllib.parse as urllib
from .connectHelper import create_connection
from requests_toolbelt.multipart import decoder
from .authorizers import admin_authorizer
from .helpers import json_serial

item_routes = Blueprint(__name__)
s3 = boto3.client('s3')

@item_routes.route('/items', methods=['GET'], cors=True)
def get_items():
    # SQL query to get all items
    sql = """
        SELECT *
        FROM items
    """

    with create_connection().cursor() as cursor:
        cursor.execute(sql)
        result = cursor.fetchall()

        # Use json_serial to serialize date, time, and timedelta fields
        serialized_result = json.loads(json.dumps(result, default=json_serial))

        return {
            "items": serialized_result
        }

@item_routes.route('/item/create', cors=True, methods=['POST'], content_types=['multipart/form-data'])
def create_item():
    try:
        # Decode the multipart/form-data using requests-toolbelt
        request = item_routes.current_request
        content_type = request.headers['content-type']
        multipart_data = decoder.MultipartDecoder(request.raw_body, content_type)

        # Initialize form data and files
        form_data = {}
        image_files = []

        # Parse each part of the multipart form-data
        for part in multipart_data.parts:
            content_disposition = part.headers.get(b'Content-Disposition', b'').decode()
            if 'filename=' in content_disposition:  # Handle file uploads
                filename = content_disposition.split('filename=')[1].strip('"')
                image_files.append((filename, part.content))
            else:  # Handle form fields
                name = content_disposition.split('name=')[1].strip('"')
                form_data[name] = part.text

        # Extract required fields from form_data
        item_name = form_data['item_name']
        description = form_data['description']
        location = form_data['location']
        date_found = form_data['date_found']
        time_found = form_data['time_found'] if 'time_found' in form_data else "00:00"

        # Combine date and time into a DATETIME string (yyyy-mm-dd HH:MM)
        found_at = f"{date_found} {time_found}"

        category = form_data['category']
        brand = form_data['brand'] if 'brand' in form_data else "Others"
        if brand == "" or brand.isspace():
            brand = "Others"

        # Process uploaded images and store them in S3
        image_urls = []
        for filename, file_content in image_files:
            s3_bucket = os.environ['S3_BUCKET_NAME']
            s3_key = f"items/{category}/{uuid.uuid4()}_{filename}"

            # Upload the image to S3
            s3.put_object(
                Bucket=s3_bucket,
                Key=s3_key,
                Body=file_content,
                ContentType='image/jpeg'
            )

            # Generate S3 URL
            image_url = f"https://{s3_bucket}.s3.amazonaws.com/{urllib.quote(s3_key)}"
            image_urls.append(image_url)

        # SQL to insert item details into the database
        sql = """
            INSERT INTO items (item_name, description, location, found_at, image_url, category, brand, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, 'unclaimed')
        """

        # Insert into the database
        with create_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql, (
                    item_name, description, location, found_at,
                    json.dumps(image_urls), category, brand
                ))
            conn.commit()

        # Return success response
        return Response(
            body=json.dumps({'message': 'Item created successfully'}),
            status_code=201,
            headers={
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        )

    except Exception as e:
        print("Error during item creation:", e)
        traceback.print_exc()
        raise BadRequestError("Failed to create item. Please try again.")

@item_routes.route('/item/{id}', cors=True, methods=['GET'])
def get_item(id):
    try:
        print("this is working")
        # SQL query to get a specific item by id
        sql = """
            SELECT *
            FROM items
            WHERE id = %s
        """

        with create_connection().cursor() as cursor:
            cursor.execute(sql, (id,))
            result = cursor.fetchone()

            if result is None:
                return Response(
                    body=json.dumps({'message': 'Item not found'}),
                    status_code=404,
                    headers={'Content-Type': 'application/json'}
                )

            # Use json_serial to serialize date, time, and timedelta fields
            serialized_result = json.loads(json.dumps(result, default=json_serial))

            return {
                "item": serialized_result
            }

    except Exception as e:
        print("Error during item retrieval:", e)
        traceback.print_exc()
        raise BadRequestError("Failed to retrieve item. Please try again.")


@item_routes.route('/item/update/{id}', cors=True, methods=['PUT'], content_types=['multipart/form-data'])
def update_item(id):
    try:
        # Decode the multipart/form-data using requests-toolbelt
        request = item_routes.current_request
        content_type = request.headers['content-type']
        multipart_data = decoder.MultipartDecoder(request.raw_body, content_type)

        # Initialize form data and files
        form_data = {}
        new_image_files = []

        # Parse each part of the multipart form-data
        for part in multipart_data.parts:
            content_disposition = part.headers.get(b'Content-Disposition', b'').decode()
            if 'filename=' in content_disposition:  # Handle file uploads
                filename = content_disposition.split('filename=')[1].strip('"')
                new_image_files.append((filename, part.content))
            else:  # Handle form fields
                name = content_disposition.split('name=')[1].strip('"')
                # For array fields like `image_url[]`, aggregate them properly
                if name == 'image_url[]':
                    if name not in form_data:
                        form_data[name] = []
                    form_data[name].append(part.text.strip())
                else:
                    form_data[name] = part.text.strip()

        # Extract form fields
        item_name = form_data.get('item_name', '')
        description = form_data.get('description', '')
        location = form_data.get('location', '')
        found_at = form_data.get('found_at', '')
        category = form_data.get('category', '')
        brand = form_data.get('brand', 'Others')
        existing_image_urls = form_data.get('image_url[]', [])

        # Process uploaded images and store them in S3
        s3_bucket = os.environ['S3_BUCKET_NAME']
        new_image_urls = []
        for filename, file_content in new_image_files:
            s3_key = f"items/{category}/{uuid.uuid4()}_{filename}"

            # Upload the image to S3
            s3.put_object(
                Bucket=s3_bucket,
                Key=s3_key,
                Body=file_content,
                ContentType='image/jpeg'
            )

            # Generate S3 URL
            image_url = f"https://{s3_bucket}.s3.amazonaws.com/{urllib.quote(s3_key)}"
            new_image_urls.append(image_url)

        # Combine existing and new image URLs
        final_image_urls = existing_image_urls + new_image_urls

        # SQL query to update the item details in the database
        sql_update = """
            UPDATE items
            SET item_name = %s, description = %s, location = %s, found_at = %s, image_url = %s, category = %s, brand = %s
            WHERE id = %s
        """

        # Connect to the database and execute the update query
        with create_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql_update, (
                    item_name, description, location, found_at,
                    json.dumps(final_image_urls), category, brand, id
                ))
            conn.commit()

        # Return success response
        return Response(
            body=json.dumps({'message': 'Item updated successfully'}),
            status_code=200,
            headers={
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        )

    except Exception as e:
        print("Error during item update:", e)
        traceback.print_exc()
        raise BadRequestError("Failed to update item. Please try again.")

@item_routes.route('/item/delete/{id}', cors=True, methods=['DELETE'])
def delete_item(id):
    try:
        # SQL query to delete the item based on the id
        sql = """
            DELETE FROM items
            WHERE id = %s
        """

        with create_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql, (id,))
                conn.commit()

        return Response(
            body=json.dumps({'message': 'Item deleted successfully'}),
            status_code=200,
            headers={'Content-Type': 'application/json'}
        )

    except Exception as e:
        print("Error during item deletion:", e)
        traceback.print_exc()
        raise BadRequestError("Failed to delete item. Please try again.")

@item_routes.route('/item/claim/{id}', cors=True, methods=['PUT'])
def claim_item(id):
    try:
        # SQL query to update the status of the item based on the id
        sql = """
            UPDATE items
            SET status = 'claimed'
            WHERE id = %s AND status = 'unclaimed'
        """

        with create_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql, (id,))
                conn.commit()

        return Response(
            body=json.dumps({'message': 'Item status updated to claimed successfully'}),
            status_code=200,
            headers={'Content-Type': 'application/json'}
        )

    except Exception as e:
        print("Error during item status update:", e)
        traceback.print_exc()
        raise BadRequestError("Failed to claim item. Please try again.")

@item_routes.route('/item/unclaim/{id}', cors=True, methods=['PUT'])
def unclaim_item(id):
    try:
        # SQL query to update the status of the item based on the id
        sql = """
            UPDATE items
            SET status = 'unclaimed'
            WHERE id = %s AND status = 'claimed'
        """

        with create_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql, (id,))
                conn.commit()

        return Response(
            body=json.dumps({'message': 'Item status updated to unclaimed successfully'}),
            status_code=200,
            headers={'Content-Type': 'application/json'}
        )

    except Exception as e:
        print("Error during item status update:", e)
        traceback.print_exc()
        raise BadRequestError("Failed to unclaim item. Please try again.")